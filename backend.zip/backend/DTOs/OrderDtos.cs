using System.ComponentModel.DataAnnotations;

namespace Arboveya.Api.DTOs;

public class CreateOrderItemDto
{
    [Required(ErrorMessage = "ProductId is required.")]
    public Guid ProductId { get; set; }

    [Required(ErrorMessage = "Quantity is required.")]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
    public int Quantity { get; set; }

    public string? ProductName { get; set; }
    public decimal? UnitPrice { get; set; }
    public string? ProductImageUrl { get; set; }
}

public class CreateOrderDto
{
    [MaxLength(150, ErrorMessage = "Customer name cannot exceed 150 characters.")]
    public string? CustomerName { get; set; }

    [EmailAddress(ErrorMessage = "Invalid email format.")]
    [MaxLength(255, ErrorMessage = "Email cannot exceed 255 characters.")]
    public string? CustomerEmail { get; set; }

    public string? ShippingAddress { get; set; }
    
    [MaxLength(100)]
    public string? Country { get; set; }

    [MaxLength(50)]
    public string? CustomerPhone { get; set; }

    [MaxLength(150)]
    public string? ShippingMethod { get; set; }

    public decimal? ShippingCost { get; set; }

    [Required(ErrorMessage = "Order must contain at least one item.")]
    [MinLength(1, ErrorMessage = "Order must contain at least one item.")]
    public List<CreateOrderItemDto> Items { get; set; } = new();
}

public class UpdateOrderStatusDto
{
    [MaxLength(50)]
    public string? OrderStatus { get; set; }

    [MaxLength(50)]
    public string? PaymentStatus { get; set; }
}

public class UpdateOrderTrackingDto
{
    [Required(ErrorMessage = "Tracking number is required.")]
    [MaxLength(150, ErrorMessage = "Tracking number cannot exceed 150 characters.")]
    public string TrackingNumber { get; set; } = string.Empty;

    [MaxLength(100, ErrorMessage = "Shipping carrier cannot exceed 100 characters.")]
    public string? ShippingCarrier { get; set; }

    [MaxLength(500, ErrorMessage = "Tracking URL cannot exceed 500 characters.")]
    public string? TrackingUrl { get; set; }

    [MaxLength(50)]
    public string? OrderStatus { get; set; } = "Shipped";
}

public class OrderItemResponseDto
{
    public Guid Id { get; set; }
    public Guid ProductId { get; set; }
    public string? ProductName { get; set; }
    public string? ProductImageUrl { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal => UnitPrice * Quantity;
}

public class OrderResponseDto
{
    public Guid Id { get; set; }
    public Guid? UserId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string ShippingAddress { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public string PaymentStatus { get; set; } = string.Empty;
    public string OrderStatus { get; set; } = string.Empty;
    public string PayHereOrderId { get; set; } = string.Empty;
    public string? PaymentId { get; set; }
    public string? TrackingNumber { get; set; }
    public string? ShippingCarrier { get; set; }
    public string? TrackingUrl { get; set; }
    public string? ShippingMethod { get; set; }
    public decimal ShippingCost { get; set; }
    public DateTime? ShippedAt { get; set; }
    public DateTime? EstimatedDeliveryDate { get; set; }
    public string RefundStatus { get; set; } = "None";
    public string? RefundReason { get; set; }
    public DateTime? RefundRequestedAt { get; set; }
    public DateTime? RefundProcessedAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string FundsStatus => (PaymentStatus.Equals("Refunded", StringComparison.OrdinalIgnoreCase) || OrderStatus.Equals("Cancelled", StringComparison.OrdinalIgnoreCase))
        ? "Cancelled / Withheld"
        : (OrderStatus.Equals("Delivered", StringComparison.OrdinalIgnoreCase) && PaymentStatus.Equals("Paid", StringComparison.OrdinalIgnoreCase)
            ? "Released"
            : "On hold");
    public List<OrderItemResponseDto> Items { get; set; } = new();
    public PayHereCheckoutDetailsDto? PayHereDetails { get; set; }
}

public class CustomerRequestRefundDto
{
    [Required(ErrorMessage = "Refund reason is required.")]
    [MaxLength(500, ErrorMessage = "Refund reason cannot exceed 500 characters.")]
    public string Reason { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Details { get; set; }
}

public class RefundOrderRequestDto
{
    [MaxLength(250)]
    public string? Reason { get; set; } = "Requested by customer";

    [Range(0.01, 1000000)]
    public decimal? Amount { get; set; }

    [MaxLength(100)]
    public string? PayHereRefundId { get; set; }

    [MaxLength(100)]
    public string? PaymentId { get; set; }

    /// <summary>
    /// When true, executes automated refund via PayHere Sandbox mode (generating sandbox refund reference or calling PayHere sandbox API).
    /// </summary>
    public bool AutoRefundSandbox { get; set; } = true;

    [MaxLength(500)]
    public string? Notes { get; set; }
}

public class PayHereCheckoutDetailsDto
{
    public bool Sandbox { get; set; } = true;
    public string ActionUrl { get; set; } = "https://sandbox.payhere.lk/pay/checkout";
    public string MerchantId { get; set; } = string.Empty;
    public string OrderId { get; set; } = string.Empty;
    public string Items { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "USD";
    public string Hash { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string DeliveryAddress { get; set; } = string.Empty;
    public string DeliveryCity { get; set; } = string.Empty;
    public string DeliveryCountry { get; set; } = string.Empty;
    public string Custom1 { get; set; } = string.Empty;
    public string Custom2 { get; set; } = string.Empty;
    public string? ReturnUrl { get; set; }
    public string? CancelUrl { get; set; }
    public string? NotifyUrl { get; set; }
}

public class PayHereNotificationDto
{
    public string? merchant_id { get; set; }
    public string? order_id { get; set; }
    public string? payment_id { get; set; }
    public string? payhere_amount { get; set; }
    public string? payhere_currency { get; set; }
    public int status_code { get; set; }
    public string? md5sig { get; set; }
    public string? custom_1 { get; set; }
    public string? custom_2 { get; set; }
    public string? status_message { get; set; }
    public string? method { get; set; }
    public string? card_holder_name { get; set; }
    public string? card_no { get; set; }
    public string? card_expiry { get; set; }
}

public class ConfirmPaymentRequestDto
{
    public string? PayHereOrderId { get; set; }
    public string? PaymentId { get; set; }
}

public class PayHereRetrievalDetailsDto
{
    public bool Found { get; set; }
    public string? PaymentId { get; set; }
    public string? OrderId { get; set; }
    public string? Status { get; set; }
    public decimal? Amount { get; set; }
    public string? Currency { get; set; }
    public string? Method { get; set; }
    public string? CardCustomerName { get; set; }
    public string? CardNumber { get; set; }
    public string? Date { get; set; }
    public string? Description { get; set; }
    public string? Message { get; set; }
}


