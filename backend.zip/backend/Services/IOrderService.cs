using Arboveya.Api.DTOs;

namespace Arboveya.Api.Services;

public interface IOrderService
{
    Task<OrderResponseDto> CreateOrderAsync(Guid? userId, CreateOrderDto dto);
    Task<OrderResponseDto?> GetByIdAsync(Guid id, Guid? currentUserId, bool isAdmin);
    Task<IEnumerable<OrderResponseDto>> GetUserOrdersAsync(Guid userId);
    Task<IEnumerable<OrderResponseDto>> GetOrdersByEmailAsync(string email);
    Task<IEnumerable<OrderResponseDto>> GetSellerOrdersAsync(Guid sellerId);
    Task<IEnumerable<OrderResponseDto>> GetAllOrdersAsync(string? orderStatus = null, string? paymentStatus = null, string? search = null);
    Task<OrderResponseDto?> UpdateOrderStatusAsync(Guid id, UpdateOrderStatusDto dto);
    Task<OrderResponseDto?> UpdateOrderTrackingAsync(Guid id, UpdateOrderTrackingDto dto);
    Task<bool> ProcessPayHereNotificationAsync(PayHereNotificationDto notification);
    Task<OrderResponseDto?> ConfirmOrderPaymentAsync(Guid orderId, string? paymentId);
    Task<OrderResponseDto?> RefundOrderAsync(
        Guid orderId, 
        string? reason = null, 
        decimal? refundAmount = null, 
        string? payHereRefundId = null, 
        string? notes = null,
        bool autoRefundSandbox = true,
        string? paymentId = null,
        Guid? currentUserId = null,
        bool isAdmin = false);
    Task<OrderResponseDto?> RequestRefundAsync(Guid orderId, CustomerRequestRefundDto dto, Guid? currentUserId, string? userEmail);
    Task<PayHereRetrievalDetailsDto?> RetrievePayHerePaymentAsync(Guid orderId, Guid? currentUserId = null, bool isAdmin = false);
}

